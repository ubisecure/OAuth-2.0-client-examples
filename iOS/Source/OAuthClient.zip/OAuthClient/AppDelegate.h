//
//  AppDelegate.h
//  OAuthClient
//
//  Copyright © 2015 Nixu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

