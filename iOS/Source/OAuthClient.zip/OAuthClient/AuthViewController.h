//
//  ViewController.h
//  OAuthClient
//
//  Copyright © 2015 Nixu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AuthViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property NSString *name;
@property NSString *email;

@end

